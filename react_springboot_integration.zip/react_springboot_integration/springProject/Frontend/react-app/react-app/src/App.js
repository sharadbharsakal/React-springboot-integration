import logo from './logo.svg';
import './App.css';
import UserComponent from './components/UserComponent';

function App() {
  return (
    <div className="App">
     
      <h2>Hii this is simple frontend and backend integration for conduiro.com</h2>
      
      <UserComponent />
        
     
    </div>
  );
}

export default App;
